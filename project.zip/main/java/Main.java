public class Main {
    public static void main(String[] args) {
        WorldTime worldTime = new WorldTime();
        System.out.println(worldTime.getTimeByCountry("America/New_York"));
    }
}
